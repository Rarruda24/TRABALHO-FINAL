<?php
session_start();
$host = 'all.c5ma20ygabza.sa-east-1.rds.amazonaws.com';
$db = 'rodrigo';
$user = 'rodrigo';
$pass = 'Rodrigo@arruda';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE username = :username AND password = :password");
        $stmt->execute(['username' => $username, 'password' => $password]);

        if ($stmt->rowCount() > 0) {
            $_SESSION['user'] = $username;
            header("Location: admin.php");
            exit();
        } else {
            echo "Login inválido!";
        }
    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <form method="POST">
        <label>Usuário:</label>
        <input type="text" name="username" required>
        <label>Senha:</label>
        <input type="password" name="password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>