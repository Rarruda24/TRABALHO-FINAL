<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Painel Administrativo</title>
</head>
<body>
    <h1>Bem-vindo ao Painel Administrativo</h1>
    <ul>
        <li><a href="produtos.php">Gerenciar Produtos</a></li>
        <li><a href="relatorios.php">Relatórios de Compras</a></li>
        <li><a href="../">Logout</a></li>
    </ul>
</body>
</html>