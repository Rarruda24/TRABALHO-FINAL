<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$host = 'all.c5ma20ygabza.sa-east-1.rds.amazonaws.com';
$db = 'rodrigo';
$user = 'rodrigo';
$pass = 'Rodrigo@arruda';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta os dados de compras
    $stmt = $pdo->query("SELECT produtos FROM compras");
    $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Relatórios de Compras</title>
</head>
<body>
    <h1>Relatório de Compras</h1>
    <ul>
        <?php
        foreach ($compras as $compra) {
            $dados = json_decode($compra['produtos'], true); // Decodifica o JSON
            foreach ($dados as $item) {
                echo "<li>";
                echo "Nome: " . $item['nome'] . "<br>";
                echo "Preço: R$" . $item['preco'] . "<br>";
                echo "Categoria: " . $item['categoria'] . "<br>";
                echo "Imagem: <img src='" . $item['imagem'] . "' alt='" . $item['nome'] . "' style='width: 100px;'><br>";
                echo "Data da compra: " . $compra['data'] . "<br>";
                echo "</li><hr>";
            }
        }
        ?>
    </ul>
</body>
</html>
