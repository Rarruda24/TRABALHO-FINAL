<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$host = 'all.c5ma20ygabza.sa-east-1.rds.amazonaws.com';
$db = 'rodrigo';
$user = 'rodrigo';
$pass = 'Rodrigo@arruda';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Processa adição de novo produto
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
        $nome = $_POST['nome'];
        $categoria = $_POST['categoria'];
        $preco = $_POST['preco'];

        $stmt = $pdo->prepare("INSERT INTO produtos (nome, categoria, preco) VALUES (:nome, :categoria, :preco)");
        $stmt->execute(['nome' => $nome, 'categoria' => $categoria, 'preco' => $preco]);
        echo "Produto adicionado com sucesso!";
    }

    // Processa edição de produto
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_product'])) {
        $id = $_POST['id'];
        $nome = $_POST['nome'];
        $categoria = $_POST['categoria'];
        $preco = $_POST['preco'];

        $stmt = $pdo->prepare("UPDATE produtos SET nome = :nome, categoria = :categoria, preco = :preco WHERE id = :id");
        $stmt->execute(['id' => $id, 'nome' => $nome, 'categoria' => $categoria, 'preco' => $preco]);
        echo "Produto atualizado com sucesso!";
    }

    // Processa exclusão de produto
    if (isset($_GET['delete'])) {
        $id = $_GET['delete'];
        $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = :id");
        $stmt->execute(['id' => $id]);
        echo "Produto excluído com sucesso!";
    }

    // Consulta produtos
    $stmt = $pdo->query("SELECT * FROM produtos");
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gerenciamento de Produtos</title>
</head>
<body>
    <h1>Produtos</h1>
    <form method="POST">
        <input type="hidden" name="add_product" value="1">
        <label>Nome:</label>
        <input type="text" name="nome" required>
        <label>Categoria:</label>
        <input type="text" name="categoria" required>
        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" required>
        <button type="submit">Adicionar Produto</button>
    </form>

    <h2>Lista de Produtos</h2>
    <ul>
        <?php foreach ($produtos as $produto): ?>
            <li>
                <?php echo $produto['nome'] . " - " . $produto['categoria'] . " - R$" . $produto['preco']; ?>
                <a href="?edit=<?php echo $produto['id']; ?>">Editar</a>
                <a href="?delete=<?php echo $produto['id']; ?>" onclick="return confirm('Tem certeza que deseja excluir este produto?');">Excluir</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <?php if (isset($_GET['edit'])): 
        $id = $_GET['edit'];
        $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $produto = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($produto): ?>
            <h2>Editar Produto</h2>
            <form method="POST">
                <input type="hidden" name="edit_product" value="1">
                <input type="hidden" name="id" value="<?php echo $produto['id']; ?>">
                <label>Nome:</label>
                <input type="text" name="nome" value="<?php echo $produto['nome']; ?>" required>
                <label>Categoria:</label>
                <input type="text" name="categoria" value="<?php echo $produto['categoria']; ?>" required>
                <label>Preço:</label>
                <input type="number" step="0.01" name="preco" value="<?php echo $produto['preco']; ?>" required>
                <button type="submit">Atualizar Produto</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>