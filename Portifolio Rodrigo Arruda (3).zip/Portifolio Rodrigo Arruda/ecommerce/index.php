<?php
// Configurações do banco de dados
$host = 'all.c5ma20ygabza.sa-east-1.rds.amazonaws.com';
$db = 'rodrigo';
$user = 'rodrigo';
$pass = 'Rodrigo@arruda';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Busca produtos no banco de dados
    $stmt = $pdo->query("SELECT nome, categoria, preco, imagem FROM produtos");
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro na conexão com o banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja - Produtos</title>
    <link rel="stylesheet" href="/rodrigo/CSS/produtos.css">
</head>
<body style="background-image: url('/rodrigo/IMAGEM/site-para-loja-virtual.jpg');">
    <header>
        <div class="container">
            <h1>Loja Virtual</h1>
            <nav>
                <a href="index.php">Produtos</a>
                <a href="carrinhodecompra.php">Carrinho</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <h2>Produtos Disponíveis</h2>
        <div class="product-list">
            <?php foreach ($produtos as $produto): ?>
                <div class="product-card">
                    <img src="<?= htmlspecialchars($produto['imagem']) ?>" alt="<?= htmlspecialchars($produto['nome']) ?>">
                    <h3><?= htmlspecialchars($produto['nome']) ?></h3>
                    <p><?= htmlspecialchars($produto['categoria']) ?></p>
                    <p><strong>R$ <?= number_format($produto['preco'], 2, ',', '.') ?></strong></p>
                    <button>Comprar</button>
                </div>
            <?php endforeach; ?>
        </div>
        
    </main>

    <script>
        // Função para adicionar produto ao carrinho
        function adicionarAoCarrinho(produto) {
            // Recuperar carrinho do localStorage (ou criar um novo array se não existir)
            let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

            // Adicionar o produto ao carrinho
            carrinho.push(produto);

            // Salvar carrinho atualizado no localStorage
            localStorage.setItem('carrinho', JSON.stringify(carrinho));

            alert('Produto adicionado ao carrinho!');
        }

        // Associar os botões "Comprar" com a função adicionarAoCarrinho
        document.addEventListener('DOMContentLoaded', () => {
            const botoes = document.querySelectorAll('.product-card button');

            botoes.forEach((botao, index) => {
                botao.addEventListener('click', () => {
                    const produtoCard = botao.closest('.product-card');
                    const produto = {
                        nome: produtoCard.querySelector('h3').textContent.trim(),
                        categoria: produtoCard.querySelector('p:nth-child(3)').textContent.trim(),
                        preco: produtoCard.querySelector('strong').textContent.replace('R$', '').trim(),
                        imagem: produtoCard.querySelector('img').src
                    };

                    adicionarAoCarrinho(produto);
                });
            });
        });
    </script>

</body>
</html>
