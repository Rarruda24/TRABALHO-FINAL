<?php
// Configurações do banco de dados
$host = 'all.c5ma20ygabza.sa-east-1.rds.amazonaws.com';
$db = 'rodrigo';
$user = 'rodrigo';
$pass = 'Rodrigo@arruda';

// Verifica se é uma solicitação POST para retornar JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $data = json_decode(file_get_contents('php://input'), true);

        if (isset($data['produtos']) && isset($data['total'])) {
            $stmt = $pdo->prepare("INSERT INTO compras (produtos, total) VALUES (:produtos, :total)");
            $stmt->execute([
                ':produtos' => json_encode($data['produtos']),
                ':total' => $data['total']
            ]);

            echo json_encode(['status' => 'success', 'message' => 'Compra finalizada com sucesso!']);
        } else {
            http_response_code(400); // Define código de erro 400 (Bad Request)
            echo json_encode(['status' => 'error', 'message' => 'Dados inválidos']);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Define código de erro 500 (Internal Server Error)
        echo json_encode(['status' => 'error', 'message' => 'Erro na conexão com o banco de dados: ' . $e->getMessage()]);
    }

    exit; // Termina a execução para evitar renderizar HTML
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras</title>
    <link rel="stylesheet" href="/rodrigo/CSS/produtos.css">
</head>
<body style="background-image: url('/rodrigo/IMAGEM/forma-de-pagamento.jpg');">
    <header>
        <h1>Carrinho de Compras</h1>
    </header>
    <main>
        <div class="container">
            <h2>Produtos no Carrinho</h2>
            <div id="carrinho"></div>
            <h3 id="total"></h3>
            <button id="finalizarCompra">Finalizar Compra</button>
        </div>
    </main>

    <script>
        // Recuperar produtos do localStorage
        const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
        const carrinhoDiv = document.getElementById('carrinho');
        const totalDiv = document.getElementById('total');

        let total = 0;

        // Exibir produtos no carrinho
        if (carrinho.length > 0) {
            carrinho.forEach(produto => {
                const preco = parseFloat(produto.preco) || 0;

                const itemDiv = document.createElement('div');
                itemDiv.innerHTML = `
                    <p><strong>Nome:</strong> ${produto.nome}</p>
                    <p><strong>Preço:</strong> R$ ${preco.toFixed(2)}</p>
                    <p><strong>Quantidade:</strong> ${produto.quantidade}</p>
                    <hr>
                `;
                carrinhoDiv.appendChild(itemDiv);

                total += preco * (produto.quantidade || 1);
            });
        } else {
            carrinhoDiv.innerHTML = '<p>O carrinho está vazio.</p>';
        }

        totalDiv.textContent = `Total: R$ ${total.toFixed(2)}`;

        // Finalizar compra
        document.getElementById('finalizarCompra').addEventListener('click', () => {
            if (carrinho.length === 0) {
                alert('Seu carrinho está vazio!');
                return;
            }

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ produtos: carrinho, total: total })
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(err.message || 'Erro desconhecido');
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    alert(data.message);
                    localStorage.removeItem('carrinho'); // Limpar o carrinho
                    location.reload();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Erro ao finalizar compra:', error);
                alert('Erro: ' + error.message);
            });
        });
    </script>
</body>
</html>
