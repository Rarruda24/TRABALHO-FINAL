<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "contatos"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


$nome = $_POST['nome'];
$email = $_POST['email'];
$mensagem = $_POST['mensagem'];


$descricao = isset($_POST['descricao']) ? $_POST['descricao'] : 'Sem descrição';


$sql = "INSERT INTO mensagens (nome, email, mensagem, descricao) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erro ao preparar a consulta: " . $conn->error);
}


$stmt->bind_param("ssss", $nome, $email, $mensagem, $descricao);


if ($stmt->execute()) {
    echo "Mensagem enviada com sucesso!";
} else {
    echo "Erro: " . $stmt->error;
}


$stmt->close();
$conn->close();
?>
