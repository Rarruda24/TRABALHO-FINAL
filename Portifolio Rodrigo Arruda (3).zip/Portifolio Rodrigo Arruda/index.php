<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfólio Rodrigo Avelino</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .fa-github {
            color: #333;
        }
        .fa-html5 {
            color: #e34c26;
        }
        .fa-css3-alt {
            color: #1572b6;
        }
        .fa-js-square {
            color: #f7df1e;
        }
        .fa-react {
            color: #61dafb;
        }
        .btn-github {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-align: center;
            width: 100%; 
        }
       
        .card {
            min-height: 400px; 
            display: flex;
            flex-direction: column;
        }
        .card-body {
            flex-grow: 1; 
        }
    </style>
</head>

<body>

    <header class="bg-dark text-white text-center py-5">
        <div class="container">
            <h1 class="display-3">Rodrigo Avelino Arruda da Silva</h1>
            <p class="lead">Desenvolvedor Web | Apaixonado por tecnologia e criação de soluções inovadoras.</p>
            <img src="IMAGEM/ilustracao-vetorial-de-personagens-de-homens-bonitos-profissionais_1287271-90696.avif" alt="Rodrigo Avelino" class="rounded-circle mb-3" style="max-width: 150px;">
        </div>
    </header>

    <section id="habilidades" class="py-5">
        <div class="container">
            <h2 class="text-center mb-4">Minhas Habilidades</h2>
            <div class="row">
                <div class="col-md-6">
                    <h3>Técnicas</h3>
                    <ul class="list-unstyled">
                        <li><i class="fab fa-html5"></i> HTML</li>
                        <li><i class="fab fa-css3-alt"></i> CSS</li>
                        <li><i class="fab fa-js-square"></i> JavaScript</li>
                        <li><i class="fab fa-react"></i> React</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h3>Soft Skills</h3>
                    <ul class="list-unstyled">
                        <li>Comunicação</li>
                        <li>Trabalho em equipe</li>
                        <li>Gestão de tempo</li>
                        <li>Resolução de problemas</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section id="projetos" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-4">Meus Projetos</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="IMAGEM/Desenvolvedor-web-front-end-2.jpg" class="card-img-top" alt="Projeto 1">
                        <div class="card-body">
                            <h5 class="card-title">Projeto 1</h5>
                            <p class="card-text">Bem-vindo ao Devflix, a sua plataforma de referência para tudo sobre a Netflix! Criado para fãs de séries e filmes...</p>
                            <a href="https://github.com/Rarruda24/NETFLIX.git" class="btn btn-primary btn-github" target="_blank"><i class="fab fa-github"></i> Ver no GitHub</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="IMAGEM/images.jfif" class="card-img-top" alt="Projeto 2">
                        <div class="card-body">
                            <h5 class="card-title">Projeto 2</h5>
                            <p class="card-text">Este perfil foi projetado para oferecer uma experiência personalizada e dinâmica, focando nas necessidades e preferências de cada usuário...</p>
                            <a href="https://github.com/Rarruda24/Perfil.git" class="btn btn-primary btn-github" target="_blank"><i class="fab fa-github"></i> Ver no GitHub</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="contato" class="py-5">
        <div class="container">
            <h2 class="text-center mb-4">Entre em Contato</h2>

            <form method="POST" id="form-contato" action="processa_formulario.php">
            <div class="mb-3">
                    <label for="nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="mensagem" class="form-label">Mensagem</label>
                    <textarea class="form-control" id="mensagem" name="mensagem" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Enviar</button>
            </form>
        </div>
    </section>

    <footer class="bg-dark text-white text-center py-3">
        <div class="container">
            <p>&copy; 2024 Rodrigo Avelino. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>

</html>


